Name: Asus VivoBook 15 X510UQR
macOS version: 10.14.6

Spec:
+ CPU: i7-8550U
+ Graphic
	- Intel(R) UHD Graphics 620
+ Monitor port
	- Internal: 1920x1080
	- HDMI: not test
	- VGA
	- DP
	- Touch Screen
+ Audio: Conexant 14F11F72
	- Speaker: OK
	- Internal Mic: not tested
	- Headphone Jack: not tested
+ Network
	- Wifi: Replace with BCM94352z
+ Keyboard
	- Brightness Adjustment: YES
	- Backlit Adjustment: YES
+ Trackpad: i2C
	- Preference: OK
	- Multi Touch
+ Webcam: OK
+ Sleep
+ USB
	- 2.0 x
	- 3.0 x
	- USB C x


